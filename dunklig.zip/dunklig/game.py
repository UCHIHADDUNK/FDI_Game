from src.main import DunkligGame

if __name__ == '__main__':
  game = DunkligGame()
  game.main()