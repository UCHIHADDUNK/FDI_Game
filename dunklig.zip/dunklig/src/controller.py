from __future__ import annotations
from typing import overload
import pygame


class CtrlMapping:
  def __new__(cls, name: str):
    if name == "Xbox Series X Controller" or name == "Xbox One Series X Controller":
      obj = {
        0: 'A',
        1: 'B',
        2: 'X',
        3: 'Y',
        4: 'LB',
        5: 'RB',
        6: 'SELECT',
        7: 'START',
        8: 'LS',
        9: 'RS',
      }
    elif name == "PS4 Controller" or name == "DualSense Wireless Controller":
      obj = {
        0: 'A',
        1: 'B',
        2: 'X',
        3: 'Y',
        4: 'SELECT',
        6: 'START',
        7: 'LS',
        8: 'RS',
        9: 'LB',
        10: 'RB',
        11: 'UP',
        12: 'DOWN',
        13: 'LEFT',
        14: 'RIGHT'
      }
    elif name == "Sony Interactive Entertainment Wireless Controller":
      obj = {
        0: 'A',
        1: 'B',
        2: 'X',
        3: 'Y',
        4: 'LB',
        5: 'RB',
        6: 'LT',
        7: 'RT',
        8: 'SELECT',
        9: 'START',
        11: 'LS',
        12: 'RS'
      }
    else:
      raise NotImplementedError(f"Unknown controller: '{name}'")
    return obj
    

class CtrlMeta(type):
  _instances: dict[int, Ctrl] = {}

  @overload 
  def __call__(self, iid: int) -> Ctrl | None: ...
  @overload 
  def __call__(self, joystick: pygame.joystick.JoystickType) -> Ctrl: ...
  def __call__(cls, val: pygame.joystick.JoystickType | int) -> Ctrl | None:
    if isinstance(val, int):
      return next((ctrl for iid, ctrl in cls._instances.items() if iid == val), None)
    iid = val.get_instance_id()
    if iid not in cls._instances:
      instance = super().__call__(val)
      cls._instances[iid] = instance
    return cls._instances[iid]


class Ctrl(metaclass=CtrlMeta): 
  def __init__(self, joystick: pygame.joystick.JoystickType) -> None:
    self.mapping = CtrlMapping(joystick.get_name())
    # self.assigned = False
    self.joystick = joystick

  @property
  def iid(self) -> int:
    return self.joystick.get_instance_id()