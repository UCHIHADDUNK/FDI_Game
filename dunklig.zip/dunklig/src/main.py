import pygame
import pygame.joystick
import pygame.mixer
from .sprites.player import Player
from .sprites.floor import Floor
from .sprites.objects import CrossingObject, RandomObject, FallingObject
from .controller import Ctrl
import os
from enum import IntEnum, auto

NEW_FALLING_OBJECT = pygame.event.custom_type()
NEW_CROSSING_OBJECT = pygame.event.custom_type()
NEW_RANDOM_OBJECT = pygame.event.custom_type()

# class GameState(IntEnum):
#   SELECTING_OPTIONS = auto()
#   PLAYING = auto()



class DunkligGame:
  def __init__(self) -> None:
    pygame.init()
    self.screen_rect = pygame.Rect(0, 0, 1024, 576)
    self.screen = pygame.display.set_mode(self.screen_rect.size)
    self.bg = pygame.image.load(os.path.join(__file__.split("src", 1).pop(0), "assets", "backgrounds", "main.jpg")).convert()
    self.players = pygame.sprite.RenderUpdates()
    self.floors = pygame.sprite.RenderPlain(
      Floor((0, 566)),
    )
    self.objects = pygame.sprite.RenderUpdates()

    self.screen.blit(self.bg, (0, 0))
    self.floors.draw(self.screen)
    pygame.display.flip()

  def main(self):
    clock = pygame.time.Clock()
    running = True
    pygame.time.set_timer(NEW_RANDOM_OBJECT, 10000)
    pygame.time.set_timer(NEW_FALLING_OBJECT, 700)
    pygame.time.set_timer(NEW_CROSSING_OBJECT, 2000)

    while running:
      clock.tick(60)
      for event in pygame.event.get():
        if event.type == pygame.QUIT:
          running = False
        elif event.type == NEW_CROSSING_OBJECT:
          self.objects.add(CrossingObject())
        elif event.type == NEW_FALLING_OBJECT:
          self.objects.add(FallingObject())
        elif event.type == NEW_RANDOM_OBJECT:
          self.objects.add(RandomObject())
        elif event.type == pygame.JOYDEVICEADDED:
          j = pygame.joystick.Joystick(event.device_index)
          Ctrl(j)
        elif event.type == pygame.JOYDEVICEREMOVED:
          p = Player(event.instance_id)
          if p is not None:
            p.iid = None
            p.kill()
        elif event.type == pygame.JOYBUTTONDOWN:
          ctrl = Ctrl(event.instance_id)
          # Technically ctrl should never be None so below will probably never be True
          if ctrl is None:
            continue
          p = Player(ctrl.iid)
          if p is None:
            continue
          # Adding a player
          if ctrl.mapping[event.button] == 'START':
            if p not in self.players:
              p.reset()
              self.players.add(p)
          elif ctrl.mapping[event.button] == "A":
            p.jump()
      
      # Detect collisions
      collisions = pygame.sprite.groupcollide(self.objects, self.players, False, False)
      if len(collisions) > 0:
        for obj, players_list in collisions.items():
          obj.kill()
          for p in players_list:
            p.damaged()

      # Remove last sprites from screen
      Player.Names.clear(self.screen, self.bg)
      Player.Hearts.clear(self.screen, self.bg)
      self.floors.clear(self.screen, self.bg)
      self.objects.clear(self.screen, self.bg)
      self.players.clear(self.screen, self.bg)
      # Update sprites
      self.objects.update(screen_rect=self.screen_rect)
      self.players.update(floors=self.floors, screen_rect=self.screen_rect)
      # Draw sprites
      Player.Names.draw(self.screen)
      Player.Hearts.draw(self.screen)
      self.floors.draw(self.screen)
      self.objects.draw(self.screen)
      self.players.draw(self.screen)
      # Update the display
      pygame.display.flip()

    # def menu_event_handler(self, event: pygame.event.Event):
    #   if event.type == pygame.JOYBUTTONDOWN:
    #     ctrl = Ctrl(event.instance_id) # TODO create player on Ctrl creation because that way if below p is None then it would be taken as an error
    #     # Technically ctrl should never be None so below will probably never be True
    #     if ctrl is None:
    #       return 
    #     # Get the player with the ctrl that triggered this event assigned, if any (None otherwise) 
    #     p = Player(ctrl.iid)
    #     # Adding a player
    #     if ctrl.mapping[event.button] == 'START' and len(self.players) < 2:
    #       # else create a new player (only if there are less than 2 players currently playing) and assign it the ctrl 
    #       if p is None:
    #         p = Player('ivan' if len(self.players) == 0 else 'dunk')
    #         # p = Player('dunk' if len(self.players) == 0 else 'ivan')
    #       else:
    #         p.reset()
    #       p.iid = ctrl.iid 
    #       self.players.add(p)
    #       return
    #     if p is None:
    #       return
    
    # def game_event_handler(self, event: pygame.event.Event):
    #   ctrl = Ctrl(event.instance_id)
    #   # Technically ctrl should never be None so below will probably never be True
    #   if ctrl is None:
    #     return
    #   # Get the player with the ctrl that triggered this event assigned, if any (None otherwise) 
    #   p = Player(ctrl.iid)
    #   if p is None:
    #     return
    #   if ctrl.mapping[event.button] == "A":
    #     p.jump()
    # def on_selecting_options(self):
    #   ...
    
    # def on_playing(self):
    #   ...

    pygame.quit()