from __future__ import annotations
import pygame, os
from random import randint, choice, getrandbits
from abc import ABCMeta, abstractmethod
from enum import IntEnum, auto

class ColisionSide(IntEnum):
  TOP = auto()
  LEFT = auto()
  RIGHT = auto()
  BOTTOM = auto()

class Object(pygame.sprite.Sprite, metaclass = ABCMeta):

  def __init__(self, name: str | None = None):
    pygame.sprite.Sprite.__init__(self)
    if name is None:
      name = choice(self.__class__.names)
    self.image = pygame.image.load(
      os.path.join(__file__.split("src", 1).pop(0), "assets", "falling_objs", f"{name}.png")
    )
    self.rect = None
    self.dx = 0
    self.dy = 0
    self.setattrs()

  @abstractmethod
  def setattrs(self):
    ...

  def update(self, screen_rect: pygame.Rect):
    self.rect.move_ip(self.dx, self.dy)
    if len(self.rect.clipline(screen_rect.topleft, screen_rect.topright)) > 0:
      self.on_colision(ColisionSide.TOP)
    elif len(self.rect.clipline(screen_rect.topright, screen_rect.bottomright)) > 0:
      self.on_colision(ColisionSide.RIGHT)
    elif len(self.rect.clipline(screen_rect.bottomleft, screen_rect.bottomright)) > 0:
      self.on_colision(ColisionSide.BOTTOM)
    elif len(self.rect.clipline(screen_rect.topleft, screen_rect.bottomleft)) > 0:
      self.on_colision(ColisionSide.LEFT)


  @abstractmethod
  def on_colision(self, side:ColisionSide): 
    ...


class FallingObject(Object):
  names = ['marge', 'snorlax']

  def setattrs(self):
    self.rect = self.image.get_rect(midtop=(randint(100, 900), 0))
    self.dx = 0
    self.dy = randint(2, 6)

  def on_colision(self, side: ColisionSide):
    if side == ColisionSide.BOTTOM:
      self.kill()


class CrossingObject(Object):  
  names = ['car']

  def setattrs(self):
    invert = getrandbits(1)
    self.dy = 0
    if invert == 1:
      self.image = pygame.transform.flip(self.image, True, False)
      self.rect = self.image.get_rect(bottom=576, left=0)
      self.dx = randint(5, 10)
    else:
      self.rect = self.image.get_rect(bottom=576, right=1024)
      self.dx = randint(-10, -5)

  def on_colision(self, side: ColisionSide):
    if side == ColisionSide.RIGHT or side == ColisionSide.LEFT:
      self.kill()


class RandomObject(Object):
  names = ['beyblade']

  def __init__(self, name: str | None = None):
    super().__init__(name)
    self.lifetime = 5000
    self.updatedAt = pygame.time.get_ticks()

  def setattrs(self):
    self.rect = self.image.get_rect(midtop=(randint(100, 900), 0))
    self.dx = randint(3, 15)
    self.dy = randint(3, 15)

  def on_colision(self, side: ColisionSide):
    if side == ColisionSide.LEFT or side == ColisionSide.RIGHT:
      self.dx *= -1
    elif side == ColisionSide.TOP or ColisionSide.BOTTOM:
      self.dy *= -1

  def update(self, screen_rect: pygame.Rect):
    super().update(screen_rect)
    if self.lifetime > 0:
      ticks = pygame.time.get_ticks()
      self.lifetime -= ticks - self.updatedAt
      self.updatedAt = ticks
    else:
      self.kill()