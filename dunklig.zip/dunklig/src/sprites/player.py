from __future__ import annotations
import pygame, os
from typing import Literal, Iterator, overload

from ..controller import Ctrl

GRAVITY = 6

class JumpAnimation:
  def __init__(self, initial_value: int, descrease: int = 1):
    self.value = initial_value
    self.decrease = descrease
  
  def __iter__(self):
    return self
  
  def __next__(self):
    if self.value <= 0:
      raise StopIteration
    val = self.value
    self.value -= self.decrease
    return -val


class MoveAnimation:
  def __init__(self, animation_speed: int | tuple[int, int, int, int] = 1):
    if isinstance(animation_speed, int):
      self.secuence = (
        *[0] * animation_speed,
        *[1] * animation_speed,
        *[0] * animation_speed,
        *[2] * animation_speed
      )
    else:
      self.secuence = (
        *[0] * animation_speed[0],
        *[1] * animation_speed[1],
        *[0] * animation_speed[2],
        *[2] * animation_speed[3]
      )
    self.idx = 0

  def __iter__(self) -> Iterator[Literal[0, 1, 2]]:
    return iter(self.secuence)
  
  def __next__(self) -> Literal[0, 1, 2]:
    val = self.secuence[self.idx]
    if self.idx == len(self.secuence) - 1:
      self.idx = 0
    else:
      self.idx += 1
    return val

  def reset(self):
    self.idx = 0


class PlayerMeta(type):
  _instances = {}
  _available_names = ('dunk', 'ivan')

  @overload
  def __call__(cls, iid: int): ...
  @overload
  def __call__(cls, name: str): ...
  def __call__(cls, value: str | int):
    if isinstance(value, int):
      player = next((p for p in cls._instances.values() if p.iid == value), None)
      if player is None:
        for name in cls._available_names:
          if name not in cls._instances:
            player = super().__call__(name)
            player.iid = value
            cls._instances[name] = player
            break
        else:
          for p in cls._instances.values():
            if p.iid is None:
              p.iid = value
              player = p
              break
      return player
    else:
      if value not in cls._instances:
        instance = super().__call__(value)
        cls._instances[value] = instance
      return cls._instances[value]
  

class Player(pygame.sprite.Sprite, metaclass=PlayerMeta):
  Hearts = pygame.sprite.RenderPlain()
  Names = pygame.sprite.RenderPlain()

  def __init__(self, name: str) -> None:
    pygame.sprite.Sprite.__init__(self)
    self.name = name
    basepath = os.path.join(__file__.split("src", 1).pop(0), "assets", "players", self.name)
    try:
      self.sounds = [
        pygame.mixer.Sound(os.path.join(basepath, f"hit_{i}.wav")) for i in range(3)
      ]
    except:
      self.sounds = []
    self.frames = {
      'left': [
        pygame.image.load(os.path.join(basepath, f"{self.name}_{i}.png")).convert_alpha() for i in range(3)
      ]
    }
    self.frames['right'] = [pygame.transform.flip(img, True, False) for img in self.frames['left']]
    self.iid: int | None = None
    self.speed = 6
    self.move_anim = MoveAnimation(4)
    self._lives = []

  def reset(self):
    self._name = Name(self.name)
    if self.name == "dunk":
      hearts = [Heart(topleft=(10, 60)), Heart(topleft=(35, 60)), Heart(topleft=(60, 60))]
    else:
      hearts = [Heart(topright=(964, 60)), Heart(topright=(989, 60)), Heart(topright=(1014, 60))]
    Player.Names.add(self._name)
    Player.Hearts.add(*hearts)
    self._lives.extend(hearts)
    self.facing = "left"
    self.jumping = None
    self.move_anim.reset()
    self.imgidx = next(self.move_anim)
    self.lives = 3
    self.standing = False
    self.rect = self.image.get_rect(center = (512, 288))

  @property
  def image(self) -> pygame.Surface:
    return self.frames[self.facing][self.imgidx]

  def damaged(self) -> None:
    self.lives -= 1
    heart = self._lives.pop()
    heart.kill()
    if len(self.sounds) > 0:
      self.sounds[2 - self.lives].play()
    if self.lives <= 0:
      self.kill()
      self._name.kill()

  def jump(self):
    if not self.standing:
      return
    self.jumping = JumpAnimation(25, 2)

  def move(self):
    if self.iid is None: 
      return
    dx = round(Ctrl(self.iid).joystick.get_axis(0))
    if dx > 0 and self.facing == 'left':
      self.move_anim.reset()
      self.facing = 'right'
    elif dx < 0 and self.facing == 'right':
      self.move_anim.reset()
      self.facing = 'left'
    if dx != 0:
      self.imgidx = next(self.move_anim)
      self.rect.move_ip(dx * self.speed, 0)
    elif self.imgidx != 0:
      self.imgidx = 0
    dy = 0
    if self.jumping is not None:
      try:
        dy = next(self.jumping)
      except StopIteration:
        self.jumping = None
      self.rect.move_ip(0, dy)


  def update(self, *, floors: pygame.sprite.Group, screen_rect: pygame.Rect) -> None:
    # Move character 
    self.move()
    # Clamp character inside the screen
    self.rect = self.rect.clamp(screen_rect)
    if not self.standing:
      colisions = pygame.sprite.spritecollide(self, floors, False)
      if len(colisions) > 0:
        self.standing = True
        self.rect.move_ip(0, colisions[0].rect.top - self.rect.bottom)
      elif self.jumping is None:
        self.rect.move_ip(0, GRAVITY)
    else:
      no_floor_below = all(len(clips) == 0 for clips in (self.rect.clipline(s.rect.left, s.rect.top - 1, s.rect.right, s.rect.top - 1) for s in floors.sprites()))
      if no_floor_below:
        self.standing = False

class Heart(pygame.sprite.Sprite):
  def __init__(self, **rect_args) -> None:
    pygame.sprite.Sprite.__init__(self)
    self.image = pygame.image.load(
      os.path.join(__file__.split("src", 1).pop(0), "assets", "static", "heart.png")
    )
    self.rect = self.image.get_rect(**rect_args)

class Name(pygame.sprite.Sprite):
  def __init__(self, name: str) -> None:
    pygame.sprite.Sprite.__init__(self)
    self.image = pygame.image.load(
      os.path.join(__file__.split("src", 1).pop(0), "assets", "players", name, "name.png")
    )
    if name == "dunk":
      self.rect = self.image.get_rect(topleft=(10, 10))
    else:
      self.rect = self.image.get_rect(topright=(1014, 10))
  

