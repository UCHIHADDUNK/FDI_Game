import pygame
import os
from typing import Literal

class Floor(pygame.sprite.Sprite):
  def __init__(self, topleft: tuple[int, int]):
    pygame.sprite.Sprite.__init__(self)
    self.image = pygame.image.load(
      os.path.join(__file__.split("src", 1).pop(0), "assets", "static", "full_floor.png")
    ).convert_alpha()
    self.rect = self.image.get_rect(topleft=topleft)
