
import pygame, os
from typing import Literal
from random import uniform

class BB_ball(pygame.sprite.Sprite):
  def __init__(self) -> None:
    pygame.sprite.Sprite.__init__(self)
    self.image = pygame.image.load(
      os.path.join(__file__.split("src", 1).pop(0), "assets", "brick_breaker", "bb_ball.png")
    ).convert_alpha()
    self.speed = 10
    self.rect = self.image.get_rect(center=(512, 50))
    self.dx = uniform(-1, 1)
    self.dy = uniform(-1, 1)

  def update(self, screen_rect: pygame.Rect):
    self.rect.move_ip(self.dx * self.speed, self.dy * self.speed)
    if len(self.rect.clipline(screen_rect.topleft, screen_rect.topright)) > 0:
      # Collided with top border
      # self.dy = uniform(0, 1)
      self.dy *= -1
    elif len(self.rect.clipline(screen_rect.topright, screen_rect.bottomright)) > 0:
      # Collided with right border
      # self.dx = uniform(-1, 0)
      self.dx *= -1
    elif len(self.rect.clipline(screen_rect.bottomleft, screen_rect.bottomright)) > 0:
      # Collided with bottom border
      # self.dy = uniform(-1, 0)
      self.dy *= -1
    elif len(self.rect.clipline(screen_rect.topleft, screen_rect.bottomleft)) > 0:
      # Collided with left border
      # self.dx = uniform(0, 1)
      self.dx *= -1

class BB_brick(pygame.sprite.Sprite):
  def __init__(self, color: Literal['blue', 'green', 'orange', 'pink', 'purple', 'red', 'yellow'], center: tuple[float, float]) -> None:
    pygame.sprite.Sprite.__init__(self)
    self.image = pygame.image.load(
      os.path.join(__file__.split("src", 1).pop(0), "assets", "brick_breaker", f"bb_{color}.png")
    ).convert_alpha()
    self.rect = self.image.get_rect(center=center)